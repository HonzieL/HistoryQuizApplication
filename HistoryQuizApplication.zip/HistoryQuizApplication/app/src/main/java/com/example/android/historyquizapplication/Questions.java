package com.example.android.historyquizapplication;

/**
 * Created by linds on 4/2/2018.
 */

public class Questions {

    public String mQuestions[] = {
            "Which historical figure said, '...From where the sun now stands I will fight no more forever?'",
            "Which indigenous language is the most commonly spoken in the US?",
            "Who was Lewis & Clark's interpreter & guide from 1804 through 1806, when they reached the Pacific Ocean?",
            "Who were the leaders of the Sioux Wars (1854 to 1890) in South Dakota, Minnesota and Wyoming?",

    };

    private String mAnswers[][] = {
            {"Chief Looking Glass of the Nez Perce", "Chief Joseph of the Nez Perce", "Chief Pontiac of the Ottawa", "Chief Seattle (Sealth) of the Duwamish & Suquamish"},
            {"Choctaw", "Cherokee (Tsalagi)", "Navajo", "Sioux"},
            {"Pocahontas", "Mourning Dove", "Toypurina (Tongva)", "Sacagawea"},
            {"Chief Crazy Horse & Chief Sitting Bull", "Wodziwob & Wovoka", "Jumping Bull & Kicking Bear", "Running Bull & Raging Waters"},

    };

    private String mCorrectAnswers[] = {"Chief Joseph of the Nez Perce", "Navajo", "Sacagawea", "Chief Crazy Horse & Chief Sitting Bull"};

    {

    }

    public String getQuestion(int a){
        String question = mQuestions[a];
        return question;
    }

    public String getAnswer1(int a){
        String answer = mAnswers[a][0];
        return answer;
    }

    public String getAnswer2(int a){
        String answer = mAnswers[a][1];
        return answer;
    }

    public String getAnswer3(int a){
        String answer = mAnswers[a][2];
        return answer;
    }

    public String getAnswer4(int a){
        String answer = mAnswers[a][3];
        return answer;
    }

    public String getCorrectAnswer(int a){
        String answer = mCorrectAnswers[a];
        return answer;
    }

}
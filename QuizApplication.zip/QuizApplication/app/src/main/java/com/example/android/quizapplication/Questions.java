package com.example.android.quizapplication;

/**
 * Created by linds on 3/27/2018.
 */

public class Questions {

    public String mQuestions[] = {
            "What was the second mate's name in 'Moby Dick'?",
            "What is 888+88+8+8+8?",
            "Who is/are considered to be the creator(s) of emoticons?",
            "What is the name of the thriving metropolis in the United States that has a booming population of one?",
            "In which US state is hunting unicorns legal?",
            "What is Cookie Monster's real name?",
            "Which animal's call does not echo?",
            "What was Dorothy's last name in 'The Wizard of Oz'?",
            "What is the maximum number of times you can fold a piece of paper in half?",
            "What percentage of people residing in the United States believe HTML is a disease?"

    };

    private String mAnswers[][] = {
            {"Ahab", "Starbuck", "Ishmael", "Elijah"},
            {"992", "976", "1,000", "984"},
            {"Vladimir Nabokov", "Dmitri Romanov", "Tanya Putinczynski", "Larry Page & Sergey Brin"},
            {"Ismay Town", "Funkley City", "Lost Springs Town", "Monowi"},
            {"Montana", "Pennsylvania", "Michigan", "New Hampshire"},
            {"Alice", "Sid", "Bruce", "Zach"},
            {"Horse", "Snake", "Duck", "Beaver"},
            {"Gale", "Bailey", "Holt", "Villebois"},
            {"Twenty-seven", "Seventy-four", "Seven", "Forty-three"},
            {"11%", "3%", "0%", "68%"}

    };

    private String mCorrectAnswers[] = {"Starbuck", "1,000", "Vladimir Nabokov", "Monowi", "Michigan", "Sid", "Duck", "Gale", "Seven", "11%"};

    {

    }

    public String getQuestion(int a){
        String question = mQuestions[a];
        return question;
    }

    public String getAnswer1(int a){
        String answer = mAnswers[a][0];
        return answer;
    }

    public String getAnswer2(int a){
        String answer = mAnswers[a][1];
        return answer;
    }

    public String getAnswer3(int a){
        String answer = mAnswers[a][2];
        return answer;
    }

    public String getAnswer4(int a){
        String answer = mAnswers[a][3];
        return answer;
    }

    public String getCorrectAnswer(int a){
        String answer = mCorrectAnswers[a];
        return answer;
    }

}
